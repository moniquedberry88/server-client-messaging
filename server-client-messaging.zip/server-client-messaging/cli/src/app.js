import { cli } from './cli'

cli.show()
